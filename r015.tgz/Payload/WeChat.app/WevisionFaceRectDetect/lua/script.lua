stickers = {}
SELF_ID = 0

Funcs = {
    onInit = function()
    end,
}

return Funcs;
