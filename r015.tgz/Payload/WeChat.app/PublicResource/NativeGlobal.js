/*
 * 在全局暴露一个 NativeGlobal 对象
 * 设计文档：http://git.code.oa.com/wxweb/game-design/blob/master/global/NativeGlobal/README.md
 */
(function() {

 // 默认从 Native 生成，如果 Native 没有生成，就声明一个
 if (typeof NativeGlobal === 'undefined') {
   NativeGlobal = {}
 }

// 有 Watcher，说明是 MagicBrushCore 环境
// 预载的时候可能用到; 环境真正拉起的时候，__wxConfig 会被覆盖掉
NativeGlobal.__wxConfig = __wxConfig;
let info = NativeGlobal.getSystemInfo();
NativeGlobal.__wxConfig.devicePixelRatio = info.pixelRatio;
NativeGlobal.__wxConfig.screenWidth = info.screenWidth;
NativeGlobal.__wxConfig.screenHeight = info.screenHeight;
NativeGlobal.findElementById = undefined;
NativeGlobal.BindingObject = NativeGlobal.Watcher;
let ScreenCanvas = NativeGlobal.ScreenCanvas;
let OffscreenCanvas = NativeGlobal.OffscreenCanvas;
var hasScreenCanvas = false
NativeGlobal.Canvas = function() {
    if (!hasScreenCanvas) {
        hasScreenCanvas = true
        return new ScreenCanvas();
    } else {
        let offscreen = new OffscreenCanvas(300, 150);
        offscreen.style = {};
        return offscreen;
    }
}
let onbindingobjectdestruct;
let EventHandler = NativeGlobal.EventHandler;
Object.defineProperty(NativeGlobal.EventHandler,'onbindingobjectdestruct', {
    get:()=>{ return onbindingobjectdestruct },
    set:(l)=>{
        if (!!onbindingobjectdestruct) {
            EventHandler.removeEventListener('watcherdestruct', onbindingobjectdestruct);
        }
        if (!!l) {
            EventHandler.addEventListener('watcherdestruct', l);
            onbindingobjectdestruct = l;
        }
}});
let performanceNow = NativeGlobal.performanceNow;
NativeGlobal.performanceNow = function() {
    return performanceNow() * 1000;
}
})();
