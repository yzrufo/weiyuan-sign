// vipbypass.m - 精确会员网关 hook (微颜/微信底层)
//
// 设计要点 (防炸核心功能):
//   1. 只 hook "类名白名单" 的类: 类名含 Vip/Member/Paid/License/Subscribe/Premium/权益
//   2. 排除微信核心类前缀 (WeChat/MM/WX/QQ 的登录聊天美颜类绝不碰)
//   3. 按 "类名 + selector" 精确匹配, 不按 selector 全类替换
//   4. install_name 用绝对路径 @executable_path/Frameworks/vipbypass.dylib (不靠 rpath)
//
// 编译 (macOS):
//   clang -arch arm64 -isysroot $(xcrun --sdk iphoneos --show-sdk-path) \
//     -miphoneos-version-min=12.0 -fobjc-arc -dynamiclib \
//     -framework Foundation -framework UIKit -lobjc \
//     -Wl,-install_name,@executable_path/Frameworks/vipbypass.dylib \
//     vipbypass.m -o vipbypass.dylib
//   codesign --force --sign - vipbypass.dylib

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stdio.h>
#include <string.h>
#define _DARWIN_C_SOURCE
#include <strings.h>   // strcasestr (Darwin)

static int imp_true(void)  { return 1; }
static int imp_false(void) { return 0; }

// 规则: selector 名 -> IMP. 只对"类名命中白名单"的类生效.
typedef struct { const char *sel; IMP imp; } Rule;
static const Rule g_rules[] = {
  {"isVip",              (IMP)imp_true},
  {"isVipStatus",        (IMP)imp_true},
  {"isMember",           (IMP)imp_true},
  {"isPaid",             (IMP)imp_true},
  {"isSubscribed",       (IMP)imp_true},
  {"isFree",             (IMP)imp_true},
  {"isPremium",          (IMP)imp_true},
  {"checkVip",           (IMP)imp_true},
  {"checkMember",        (IMP)imp_true},
  {"needPay",            (IMP)imp_false},
  {"needRecharge",       (IMP)imp_false},
  {"isExpired",          (IMP)imp_false},
  {"isTrialTimeout",     (IMP)imp_false},
};
static const int g_ruleCount = sizeof(g_rules)/sizeof(g_rules[0]);

// 类名白名单: 只有类名(不区分大小写)含这些词才 hook
static const char *g_classAllow[] = {
  "vip","member","paid","license","subscribe","premium","entitle","权益","特权","会员","svip",
};
// 类名黑名单: 含这些词的类绝不碰 (微信核心)
static const char *g_classBlock[] = {
  "wechat","wx","mm_","mm-","chat","login","beauty","meiyan","美颜","face","video","call",
  "paycenter","iapp","iap","applepay","weixin","friends","contact","message","media","plugin",
};

static int g_hooked = 0;

static int classAllowed(const char *name) {
    if (!name) return 0;
    char tmp[256];
    size_t n = strlen(name); if (n >= sizeof(tmp)) n = sizeof(tmp)-1;
    memcpy(tmp, name, n); tmp[n] = 0;
    // 黑名单优先
    for (int b = 0; b < (int)(sizeof(g_classBlock)/sizeof(char*)); b++)
        if (strcasestr(tmp, g_classBlock[b])) return 0;
    for (int a = 0; a < (int)(sizeof(g_classAllow)/sizeof(char*)); a++)
        if (strcasestr(tmp, g_classAllow[a])) return 1;
    return 0;
}

static void installHooks(void) {
    int total = objc_getClassList(NULL, 0);
    if (total <= 0) return;
    Class *classes = (Class *)malloc(sizeof(Class) * total);
    if (!classes) return;
    int got = objc_getClassList(classes, total);
    if (got < 0) { free(classes); return; }
    for (int i = 0; i < got; i++) {
        Class c = classes[i];
        const char *cname = class_getName(c);
        if (class_isMetaClass(c) || !cname) continue;
        if (!classAllowed(cname)) continue;   // 非会员类直接跳
        unsigned int mcount = 0;
        Method *methods = class_copyMethodList(c, &mcount);
        if (!methods) continue;
        for (unsigned int m = 0; m < mcount; m++) {
            SEL sel = method_getName(methods[m]);
            const char *selName = sel_getName(sel);
            for (int r = 0; r < g_ruleCount; r++) {
                if (strcmp(selName, g_rules[r].sel) == 0) {
                    method_setImplementation(methods[m], g_rules[r].imp);
                    g_hooked++;
                    fprintf(stderr, "[VIP] %s.%s -> %s\n", cname, selName,
                            g_rules[r].imp == (IMP)imp_true ? "true" : "false");
                }
            }
        }
        free(methods);
    }
    free(classes);
}

__attribute__((constructor))
static void vipbypass_init(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        installHooks();
        fprintf(stderr, "[VIP] bypass armed (class-filtered), hooked=%d\n", g_hooked);
    });
}
