// vipbypass.m - 自注入 dylib: 常驻 hook 微颜 (com.gjz.myt) 的会员网关
//
// 编译 (macOS, Xcode CLT):
//   clang -arch arm64 -isysroot $(xcrun --sdk iphoneos --show-sdk-path) \
//     -miphoneos-version-min=12.0 -fobjc-arc -dynamiclib \
//     -framework Foundation -framework UIKit -lobjc \
//     vipbypass.m -o libvipbypass.dylib
//
// 注入: 把 libvipbypass.dylib 放进 app/Frameworks/, 往主二进制加
//   LC_LOAD_DYLIB @rpath/libvipbypass.dylib + LC_RPATH @executable_path/Frameworks
//   (用同目录 inject_dylib.py), 然后 codesign --force --deep --sign - 重签.
//
// 设计:
//   - 不用 mmap RWX (iOS W^X 会拒). 每个规则对应一个编译进 __text 的真实 C 函数
//     (返回固定 0/1), 用 method_setImplementation 直接替换.
//   - constructor 在 main queue 延迟到 runtime ready 再装 hook.

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stdio.h>
#include <string.h>

// ---- 固定返回值的 C 函数 (链接器放进 __text, 可直接作 IMP) ----
static int imp_true(void)   { return 1; }
static int imp_false(void)  { return 0; }

// 规则: selector 名 -> 用哪个 IMP 替换
typedef struct { const char *sel; IMP imp; } Rule;

static const Rule g_rules[] = {
  // 会员/付费 -> 是
  {"isVip",                 (IMP)imp_true},
  {"isVipStatus",           (IMP)imp_true},
  {"isMember",              (IMP)imp_true},
  {"isMemberFree",          (IMP)imp_true},
  {"isPaid",                (IMP)imp_true},
  {"isPaidContent",         (IMP)imp_true},
  {"isPaidStickers",        (IMP)imp_true},
  {"isPaidForNextRound",    (IMP)imp_true},
  {"isSubscribed",          (IMP)imp_true},
  {"isSubscribed_36",       (IMP)imp_true},
  {"isFree",                (IMP)imp_true},
  {"isFreeItem",            (IMP)imp_true},
  {"isFreeContent",         (IMP)imp_true},
  {"isFreeGift",            (IMP)imp_true},
  {"hasSubscribedCard",     (IMP)imp_true},
  {"checkVip",              (IMP)imp_true},
  {"checkMember",           (IMP)imp_true},
  {"isPrivilegedAudience",  (IMP)imp_true},
  // 需要付费/过期 -> 否
  {"needPay",               (IMP)imp_false},
  {"needRecharge",          (IMP)imp_false},
  {"needPayForLive",        (IMP)imp_false},
  {"isExpired",             (IMP)imp_false},
  {"isExpiredForRevoking",  (IMP)imp_false},
  {"isExpiredShowInfo",     (IMP)imp_false},
  {"isTrialTimeout",        (IMP)imp_false},
  {"isTrialListenPlaying",  (IMP)imp_false},
};
static const int g_ruleCount = sizeof(g_rules)/sizeof(g_rules[0]);

static int g_hooked = 0;

static void installHooks(void) {
    // 拿所有已注册类
    int total = 0;
    Class *classes = objc_getClassList(NULL, &total);
    if (!classes) return;
    for (unsigned int i = 0; i < total; i++) {
        Class c = classes[i];
        const char *cname = class_getName(c);
        if (!cname) continue;
        // 只处理非 meta、有实例方法的类
        if (class_isMetaClass(c)) continue;
        unsigned int mcount = 0;
        Method *methods = class_copyMethodList(c, &mcount);
        if (!methods) continue;
        for (unsigned int m = 0; m < mcount; m++) {
            SEL sel = method_getName(methods[m]);
            const char *selName = sel_getName(sel);
            for (int r = 0; r < g_ruleCount; r++) {
                if (strcmp(selName, g_rules[r].sel) == 0) {
                    method_setImplementation(methods[m], g_rules[r].imp);
                    g_hooked++;
                    fprintf(stderr, "[VIP] %s.%s forced\n", cname, selName);
                }
            }
        }
        free(methods);
    }
    free(classes);
}

__attribute__((constructor))
static void vipbypass_init(void) {
    // 等 runtime 加载完 (constructor 可能早于类注册)
    dispatch_async(dispatch_get_main_queue(), ^{
        installHooks();
        fprintf(stderr, "[VIP] bypass armed, hooked=%d\n", g_hooked);
    });
}
