// vipbypass.m - ????????? hook (???/??????)
//
// ?????? (?????????):
//   1. ??hook "???????? ???: ?????Vip/Member/Paid/License/Subscribe/Premium/???
//   2. ?????????????? (WeChat/MM/WX/QQ ?????????????????
//   3. ??"??? + selector" ??????, ??? selector ??????
//   4. install_name ????????@executable_path/Frameworks/vipbypass.dylib (??? rpath)
//
// ??? (macOS):
//   clang -arch arm64 -isysroot $(xcrun --sdk iphoneos --show-sdk-path) \
//     -miphoneos-version-min=12.0 -fobjc-arc -dynamiclib \
//     -framework Foundation -framework UIKit -lobjc \
//     -Wl,-install_name,@executable_path/Frameworks/vipbypass.dylib \
//     vipbypass.m -o vipbypass.dylib
//   codesign --force --sign - vipbypass.dylib

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stdio.h>
#include <string.h>

static int imp_true(void)  { return 1; }
static int imp_false(void) { return 0; }

// ???: selector ??-> IMP. ???"?????????????????.
typedef struct { const char *sel; IMP imp; } Rule;
static const Rule g_rules[] = {
  {"isVip",              (IMP)imp_true},
  {"isVipStatus",        (IMP)imp_true},
  {"isMember",           (IMP)imp_true},
  {"isPaid",             (IMP)imp_true},
  {"isSubscribed",       (IMP)imp_true},
  {"isFree",             (IMP)imp_true},
  {"isPremium",          (IMP)imp_true},
  {"checkVip",           (IMP)imp_true},
  {"checkMember",        (IMP)imp_true},
  {"needPay",            (IMP)imp_false},
  {"needRecharge",       (IMP)imp_false},
  {"isExpired",          (IMP)imp_false},
  {"isTrialTimeout",     (IMP)imp_false},
};
static const int g_ruleCount = sizeof(g_rules)/sizeof(g_rules[0]);

// ???????? ???????????(MY_/My/Beauty ???, ??? MYSkin.bundle/MYStyle.bundle)
// ???????????(WCPay/WX*/Ecs*/Chat*/Group*/Login*/Face*/Midas* ??
static const char *g_classAllow[] = {
  "beauty","myskin","mystyle","mycard","my_","myvideo","myfilter","mybeauty",
};
// ???????? ?????? + ???/???/??????????static const char *g_classBlock[] = {
  "wx","wc","ecs","mm","chat","group","gc","fts","brand","extra","qzone",
  "check","apple","honey","midas","face","iwcp","tt","member","pay","login","login",
  "video","call","message","media","contact","friends","plugin","timeline","invoice",
  "favorites","redpacket","stranger","wcdb","wctime","card","profile","notice","room",
};

static int g_hooked = 0;

// ??C ??????????????? (?????strcasestr/_DARWIN_C_SOURCE)
static int ci_contains(const char *hay, const char *needle) {
    if (!hay || !needle) return 0;
    size_t hn = strlen(hay), nn = strlen(needle);
    if (nn == 0 || hn < nn) return 0;
    for (size_t i = 0; i + nn <= hn; i++) {
        int ok = 1;
        for (size_t j = 0; j < nn; j++) {
            char a = hay[i+j], b = needle[j];
            if (a >= 'A' && a <= 'Z') a += 32;
            if (b >= 'A' && b <= 'Z') b += 32;
            if (a != b) { ok = 0; break; }
        }
        if (ok) return 1;
    }
    return 0;
}

static int classAllowed(const char *name) {
    if (!name) return 0;
    // ????????    for (int b = 0; b < (int)(sizeof(g_classBlock)/sizeof(char*)); b++)
        if (ci_contains(name, g_classBlock[b])) return 0;
    for (int a = 0; a < (int)(sizeof(g_classAllow)/sizeof(char*)); a++)
        if (ci_contains(name, g_classAllow[a])) return 1;
    return 0;
}

static void installHooks(void) {
    int total = objc_getClassList(NULL, 0);
    if (total <= 0) return;
    Class *classes = (Class *)malloc(sizeof(Class) * total);
    if (!classes) return;
    int got = objc_getClassList(classes, total);
    if (got < 0) { free(classes); return; }
    for (int i = 0; i < got; i++) {
        Class c = classes[i];
        const char *cname = class_getName(c);
        if (class_isMetaClass(c) || !cname) continue;
        if (!classAllowed(cname)) continue;   // ???????????        unsigned int mcount = 0;
        Method *methods = class_copyMethodList(c, &mcount);
        if (!methods) continue;
        for (unsigned int m = 0; m < mcount; m++) {
            SEL sel = method_getName(methods[m]);
            const char *selName = sel_getName(sel);
            for (int r = 0; r < g_ruleCount; r++) {
                if (strcmp(selName, g_rules[r].sel) == 0) {
                    method_setImplementation(methods[m], g_rules[r].imp);
                    g_hooked++;
                    fprintf(stderr, "[VIP] %s.%s -> %s\n", cname, selName,
                            g_rules[r].imp == (IMP)imp_true ? "true" : "false");
                }
            }
        }
        free(methods);
    }
    free(classes);
}

__attribute__((constructor))
static void vipbypass_init(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        installHooks();
        fprintf(stderr, "[VIP] bypass armed (class-filtered), hooked=%d\n", g_hooked);
    });
}
