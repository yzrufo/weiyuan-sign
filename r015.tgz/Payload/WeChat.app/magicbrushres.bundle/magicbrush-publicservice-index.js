console.info("public service init!");

var bizSet = new Set();

mb.onBizConnected = (biz) => {
    console.log('biz connected!', biz);
    globalThis.bizSet.add(biz);
};

mb.onBizDisconnected = (biz) => {
    console.log('biz disconnected!', biz);
    globalThis.bizSet.delete(biz);
};
