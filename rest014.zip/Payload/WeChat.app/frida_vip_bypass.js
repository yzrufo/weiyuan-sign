/*
 * Weiyuan (com.gjz.myt) 8.0.75 - VIP / 会员充值绕过 (真正 gating 层)
 *
 * 之前 frida_bypass.js hook 的是 license/scan 回调（服务端 CGI 层），
 * 但"要充值"真正卡的是会员网关：isVip / isMember / isPaid / needPay /
 * isExpired / isSubscribed。本脚本按 selector 名扫描全部实现类，
 * 强制这些判定返回"已付费 / 是 VIP / 不需要付费 / 未过期"。
 *
 * 用法:
 *   frida -U -f com.gjz.myt -l frida_vip_bypass.js --codesign
 *   # 或附加到已运行: frida -U -n WeChat -l frida_vip_bypass.js
 *
 * 说明:
 *   - BOOL 判定 (isVip/isMember/isPaid/isSubscribed/isExpired) -> 返回 1/0
 *   - needPay -> 返回 0 (不需要付费)
 *   - 若某 selector 不存在/多实现, 脚本会逐个尝试, 失败不致命
 */

"use strict";

function allClasses() {
  if (typeof ObjC !== "undefined") {
    try { return ObjC.enumerateClassesSync ? ObjC.enumerateClassesSync() : Object.keys(ObjC.classes); }
    catch (e) {}
  }
  return Object.keys(ObjC.classes);
}

// selector -> { ret: 强制返回值, desc: 说明 }
// BOOL methods return an integer in W0 (0/1). For "isVip/isMember/isPaid/isSubscribed" we want 1 (true).
// For "isExpired" we want 0 (not expired). For "needPay" we want 0 (no pay needed).
const FORCE = {
  "isVip":                 { ret: 1, desc: "强制为 VIP" },
  "isVipStatus":           { ret: 1, desc: "强制 VIP 状态" },
  "isMember":              { ret: 1, desc: "强制为会员" },
  "isMemberFree":          { ret: 1, desc: "强制会员免费权益" },
  "isPaid":                { ret: 1, desc: "强制已付费" },
  "isPaidContent":         { ret: 1, desc: "强制内容已付费" },
  "isPaidStickers":        { ret: 1, desc: "强制贴纸已付费" },
  "isSubscribed":          { ret: 1, desc: "强制已订阅" },
  "isSubscribed_36":       { ret: 1, desc: "强制订阅(36)" },
  "needPay":               { ret: 0, desc: "强制不需要付费" },
  "needRecharge":          { ret: 0, desc: "强制不需要充值" },
  "isExpired":             { ret: 0, desc: "强制未过期" },
  "isTrialTimeout":        { ret: 0, desc: "强制试用未超时" },
  "isFree":                { ret: 1, desc: "强制免费" },
  "isFreeItem":            { ret: 1, desc: "强制项目免费" },
  "isFreeContent":         { ret: 1, desc: "强制内容免费" },
  "hasSubscribedCard":     { ret: 1, desc: "强制持有订阅卡" },
  "checkVip":              { ret: 1, desc: "强制 VIP 校验通过" },
  "checkMember":           { ret: 1, desc: "强制会员校验通过" },
  "isPrivilegedAudience":  { ret: 1, desc: "强制特权观众" },
  "isPaidForNextRound":    { ret: 1, desc: "强制下一轮已付费" },
};

let hooked = 0;
let skipped = 0;

function hookSel(selName, spec) {
  const sel = ObjC.selectorByName(selName);
  if (!sel) { console.log("  [skip] selector not found: " + selName); skipped++; return; }
  // enumerate every class implementing this selector
  const impls = [];
  try {
    for (const clsName in ObjC.classes) {
      const cls = ObjC.classes[clsName];
      if (!cls) continue;
      // does this class have the method (including inherited)?
      if (cls[sel] || (cls.$objcMetaClass && cls.$objcMetaClass[sel])) {
        impls.push(clsName);
      }
    }
  } catch (e) {
    console.log("  [!] enumerate failed: " + e);
  }
  if (impls.length === 0) {
    console.log("  [skip] no implementer for " + selName);
    skipped++;
    return;
  }
  // hook only the most concrete implementer(s). Hooking all may over-force;
  // we hook each, but guard against re-hooking the same IMP.
  const seenImp = {};
  for (const clsName of impls) {
    const cls = ObjC.classes[clsName];
    let method = cls[sel];
    if (!method) continue;
    const imp = method.implementation;
    if (seenImp[imp]) continue;
    seenImp[imp] = true;
    try {
      const Ctor = method.implementation.constructor;
      Interceptor.replace(imp, new Ctor(function (...args) {
        console.log("[FORCE] " + clsName + " " + selName + " -> " + spec.ret + " (" + spec.desc + ")");
        return spec.ret;
      }));
      console.log("  [+] hooked " + clsName + " " + selName + " ret=" + spec.ret + "  " + spec.desc);
      hooked++;
    } catch (e) {
      console.log("  [!] hook fail " + clsName + " " + selName + ": " + e);
    }
  }
}

// ---- 也强制 IAP receipt 解析认为"已购买" ----
function forceIAP() {
  // BrandIAPPrepayRequest / PurchasesReceiptParser etc. — force purchase status
  ["purchasedProducts", "purchasedProductIdentifiers", "allPurchasedProducts", "hasPurchasedProduct", "isProductPurchased", "purchasedStatus"].forEach(function (s) {
    const spec = { ret: 1, desc: "IAP 已购" };
    // only if selector exists
    try { if (ObjC.selectorByName(s)) hookSel(s, spec); } catch (e) {}
  });
}

// Also force the KVC property setters that cache membership state, so the
// app's in-memory "am I a member" flag can never flip back to false.
const FORCE_SET = {
  "setVipStatus":            { ret: null, setTrue: 1, desc: "缓存 VIP 状态=是" },
  "setMemberStatus":         { ret: null, setTrue: 1, desc: "缓存会员状态=是" },
  "setIsVip":                { ret: null, setTrue: 1, desc: "缓存 isVip=是" },
  "setIsMember":             { ret: null, setTrue: 1, desc: "缓存 isMember=是" },
  "setIsPaid":               { ret: null, setTrue: 1, desc: "缓存 isPaid=是" },
  "setSubscribeStatus":      { ret: null, setTrue: 1, desc: "缓存订阅状态" },
  "setIsSubscribed":         { ret: null, setTrue: 1, desc: "缓存 isSubscribed=是" },
  "setExpired":              { ret: null, setTrue: 0, desc: "缓存 expired=否" },
};
function hookSet(selName, spec) {
  const sel = ObjC.selectorByName(selName);
  if (!sel) return;
  for (const clsName in ObjC.classes) {
    const cls = ObjC.classes[clsName];
    if (!cls || !cls[sel]) continue;
    try {
      const imp = cls[sel].implementation;
      const Ctor = cls[sel].implementation.constructor;
      // setter ignores the incoming value, forces the desired state
      Interceptor.replace(imp, new Ctor(function (inst, _val) {
        // forward to original? No — just swallow; the getter is already forced.
        return undefined;
      }));
      console.log("  [+] forced setter " + clsName + " " + selName + " (" + spec.desc + ")");
      hooked++;
    } catch (e) {}
  }
}

console.log("=== Weiyuan VIP bypass: scanning " + Object.keys(FORCE).length + " gating + " + Object.keys(FORCE_SET).length + " setters ===");
for (const selName in FORCE) hookSel(selName, FORCE[selName]);
for (const selName in FORCE_SET) hookSet(selName, FORCE_SET[selName]);
forceIAP();
console.log("=== done. hooked=" + hooked + " skipped=" + skipped + " ===");
console.log("Watch console for [FORCE]/[+] lines as the app queries membership state.");

